#ifndef __TLS_CONFIG_H__
#define __TLS_CONFIG_H__

// WolfSSL or mbedTLS
//#define USE_WOLF_SSL
#define USE_MBED_TLS

#endif // __TLS_CONFIG_H__